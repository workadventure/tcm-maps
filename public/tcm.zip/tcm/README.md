# WorkAdventure Map Starter Kit - Public Folder

In this directory you can put static files (audio files, PDFs, videos, images except tileset...) that you want to be present to the players.
